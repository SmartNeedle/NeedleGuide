﻿namespace Sunny_Drive_Arcus_DMX_UMD_23_v01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CB_DeviceList = new System.Windows.Forms.ComboBox();
            this.bt_DeviceConnection = new System.Windows.Forms.Button();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.lb_statusStrip = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_CommandSend = new System.Windows.Forms.TextBox();
            this.txt_DeviceReply = new System.Windows.Forms.TextBox();
            this.bt_SendCommand = new System.Windows.Forms.Button();
            this.statusStrip.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CB_DeviceList
            // 
            this.CB_DeviceList.FormattingEnabled = true;
            this.CB_DeviceList.Location = new System.Drawing.Point(12, 12);
            this.CB_DeviceList.Name = "CB_DeviceList";
            this.CB_DeviceList.Size = new System.Drawing.Size(382, 21);
            this.CB_DeviceList.TabIndex = 0;
            // 
            // bt_DeviceConnection
            // 
            this.bt_DeviceConnection.Location = new System.Drawing.Point(400, 12);
            this.bt_DeviceConnection.Name = "bt_DeviceConnection";
            this.bt_DeviceConnection.Size = new System.Drawing.Size(88, 20);
            this.bt_DeviceConnection.TabIndex = 1;
            this.bt_DeviceConnection.Text = "Connect";
            this.bt_DeviceConnection.UseVisualStyleBackColor = true;
            this.bt_DeviceConnection.Click += new System.EventHandler(this.bt_DeviceConnection_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lb_statusStrip});
            this.statusStrip.Location = new System.Drawing.Point(0, 215);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(500, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "Status Strip Bar";
            // 
            // lb_statusStrip
            // 
            this.lb_statusStrip.Name = "lb_statusStrip";
            this.lb_statusStrip.Size = new System.Drawing.Size(125, 17);
            this.lb_statusStrip.Text = "No device is connected~";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.bt_SendCommand);
            this.groupBox1.Controls.Add(this.txt_DeviceReply);
            this.groupBox1.Controls.Add(this.txt_CommandSend);
            this.groupBox1.Location = new System.Drawing.Point(12, 39);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(382, 163);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Command Line Center";
            // 
            // txt_CommandSend
            // 
            this.txt_CommandSend.Location = new System.Drawing.Point(6, 27);
            this.txt_CommandSend.Name = "txt_CommandSend";
            this.txt_CommandSend.Size = new System.Drawing.Size(289, 20);
            this.txt_CommandSend.TabIndex = 0;
            // 
            // txt_DeviceReply
            // 
            this.txt_DeviceReply.Location = new System.Drawing.Point(6, 53);
            this.txt_DeviceReply.Multiline = true;
            this.txt_DeviceReply.Name = "txt_DeviceReply";
            this.txt_DeviceReply.ReadOnly = true;
            this.txt_DeviceReply.Size = new System.Drawing.Size(289, 104);
            this.txt_DeviceReply.TabIndex = 1;
            // 
            // bt_SendCommand
            // 
            this.bt_SendCommand.Location = new System.Drawing.Point(301, 25);
            this.bt_SendCommand.Name = "bt_SendCommand";
            this.bt_SendCommand.Size = new System.Drawing.Size(75, 23);
            this.bt_SendCommand.TabIndex = 2;
            this.bt_SendCommand.Text = "Send >>";
            this.bt_SendCommand.UseVisualStyleBackColor = true;
            this.bt_SendCommand.Click += new System.EventHandler(this.bt_SendCommand_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 237);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.bt_DeviceConnection);
            this.Controls.Add(this.CB_DeviceList);
            this.Name = "Form1";
            this.Text = "Sunny is driving ARCUS DMX-UMD-23";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox CB_DeviceList;
        private System.Windows.Forms.Button bt_DeviceConnection;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel lb_statusStrip;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_DeviceReply;
        private System.Windows.Forms.TextBox txt_CommandSend;
        private System.Windows.Forms.Button bt_SendCommand;
    }
}

