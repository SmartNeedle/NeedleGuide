﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sunny_Drive_Arcus_DMX_UMD_23_v01
{
    public partial class Form1 : Form
    {

        private DMX_UMD_Ctrl_Fcn DMX_UMD_API = new DMX_UMD_Ctrl_Fcn();
        private IntPtr hUSBDevice;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] deviceList;

            deviceList = DMX_UMD_API.GetDeviceList();

            if (deviceList[0] == null)
            {
                this.Close();
            }
            else
            {
                for (byte deviceCount = 0; deviceCount < deviceList.Length; deviceCount++)
                {
                    if (deviceList[deviceCount] != null)
                        CB_DeviceList.Items.Add(deviceList[deviceCount]);
                    
                }

            }

            
        }

        private void bt_DeviceConnection_Click(object sender, EventArgs e)
        {
            bool connectionStatus = false;
//            MessageBox.Show(CB_DeviceList.SelectedIndex.ToString());
            
            if ((bt_DeviceConnection.Text == "Connect") & (CB_DeviceList.SelectedIndex >= 0))
            {

                connectionStatus = DMX_UMD_API.connectToDevice(DMX_UMD_API.resolveDeviceIndex(CB_DeviceList.SelectedItem.ToString()), out hUSBDevice);

                if (connectionStatus == false)
                {
                    MessageBox.Show("Failed to connect with the device... Please check the power or USB connection");
                }
                else  // true status.. connnected to the device...
                {
                    bt_DeviceConnection.Text = "Disconnect";
                    lb_statusStrip.Text = CB_DeviceList.SelectedItem.ToString() + " is connected successfully!";
                }

            }
            else if (bt_DeviceConnection.Text == "Disconnect")
            {
                connectionStatus = DMX_UMD_API.disconnectToDevice(hUSBDevice);

                if (connectionStatus == false)
                {
                    MessageBox.Show("Failed to disconnect the device....");
                }
                else
                {
                    CB_DeviceList.SelectedIndex = -1;
                    bt_DeviceConnection.Text = "Connect";
                    lb_statusStrip.Text = "No device is connected~";
                }
            }
            else if (CB_DeviceList.SelectedIndex < 0)
            {
                MessageBox.Show("Please select a Performax device first");
            }

             
        }

        private void bt_SendCommand_Click(object sender, EventArgs e)
        {
            string tmpString = "";
            bool status;
            status = DMX_UMD_API.performaxSendAndGetReply(hUSBDevice, txt_CommandSend.Text, out tmpString);
            if (status)
            {
                txt_DeviceReply.Text = tmpString + "\r\n" + txt_DeviceReply.Text;
            }
            else
            {
                MessageBox.Show("Warning.... send command error ~~");
            }
            
        }

 
    }
}
