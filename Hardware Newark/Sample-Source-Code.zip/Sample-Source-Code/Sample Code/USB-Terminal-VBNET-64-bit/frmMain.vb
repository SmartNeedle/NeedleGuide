﻿Public Class frmMain

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub CommandText_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles CommandText.KeyDown
        Dim cmdStr As String = ""
        Dim replyStr As String = ""
        Dim ret As Integer = 0

        If (e.KeyCode = 13) Then 'keycode 13 = carriage return
            cmdStr = CommandText.Text
            'PerformaxSendGetReply uses DLL function fnPerformaxComSendRcv for sending commands and receiving replies
            replyStr = PerformaxSendGetReply(cmdStr)
            ReplyText.Text = replyStr 'Show the reply given from the Performax device
            CommandText.Text = ""
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        fnPerformaxComClose(hUSBDevice)
        End
    End Sub
End Class