Before Running:
Make sure to have 64-bit PerformaxCom.DLL and 64-bit SiUSBXp.DLL in C:\Windows\System32 Folder.

To access 64-bit application:
bin --> x64 --> Debug --> PMX_Terminal_VB_NET.exe