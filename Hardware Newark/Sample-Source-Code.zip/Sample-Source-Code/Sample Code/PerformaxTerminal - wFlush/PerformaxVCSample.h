// PerformaxVCSample.h : main header file for the PERFORMAXVCSAMPLE application
//

#if !defined(AFX_PERFORMAXVCSAMPLE_H__3D7C4ECE_3D16_4639_B706_7A9A066C81B4__INCLUDED_)
#define AFX_PERFORMAXVCSAMPLE_H__3D7C4ECE_3D16_4639_B706_7A9A066C81B4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CPerformaxVCSampleApp:
// See PerformaxVCSample.cpp for the implementation of this class
//

class CPerformaxVCSampleApp : public CWinApp
{
public:
	CPerformaxVCSampleApp();
	DWORD GetNumDevices(){return m_dwNumDevices;}

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPerformaxVCSampleApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

protected:
	DWORD m_dwNumDevices;

// Implementation
	//{{AFX_MSG(CPerformaxVCSampleApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PERFORMAXVCSAMPLE_H__3D7C4ECE_3D16_4639_B706_7A9A066C81B4__INCLUDED_)
