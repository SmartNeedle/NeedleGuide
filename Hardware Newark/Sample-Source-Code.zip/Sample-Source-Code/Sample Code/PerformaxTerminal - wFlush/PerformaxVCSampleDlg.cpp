// PerformaxVCSampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PerformaxVCSample.h"
#include "PerformaxVCSampleDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define PERFORMAX_RETURN_SERIAL_NUMBER		0
#define PERFORMAX_RETURN_DESCRIPTION		1
#define COMND_BUF_LEN						255
#define REPLY_BUF_LEN						6000

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPerformaxVCSampleDlg dialog

CPerformaxVCSampleDlg::CPerformaxVCSampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPerformaxVCSampleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPerformaxVCSampleDlg)
	m_strCommand = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CPerformaxVCSampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPerformaxVCSampleDlg)
	DDX_Control(pDX, IDC_BUTTON_SEND, m_BtnSend);
	DDX_Control(pDX, IDC_BUTTON_DISCONNECT, m_BtnDisConnect);
	DDX_Control(pDX, IDC_BUTTON_FLUSH, m_BtnFlush);
	DDX_Control(pDX, IDC_BUTTON_CONNECT, m_BtnConnect);
	DDX_Control(pDX, IDC_LIST_REPLY, m_ListBoxReply);
	DDX_Control(pDX, IDC_DEVICE_LIST, m_CombDeviceList);
	DDX_Text(pDX, IDC_EDIT_COMMAND, m_strCommand);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPerformaxVCSampleDlg, CDialog)
	//{{AFX_MSG_MAP(CPerformaxVCSampleDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_CONNECT, OnConnect)
	ON_BN_CLICKED(IDC_BUTTON_DISCONNECT, OnDisconnect)
	ON_BN_CLICKED(IDC_BUTTON_SEND, OnSend)
	ON_EN_CHANGE(IDC_EDIT_COMMAND, OnChangeEditCommand)
	ON_BN_CLICKED(IDC_BUTTON_FLUSH, OnButtonFlush)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPerformaxVCSampleDlg message handlers

BOOL CPerformaxVCSampleDlg::OnInitDialog()
{
	DWORD	dwNumDevices, i;
	char	ProductString[128];

	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	dwNumDevices = ((CPerformaxVCSampleApp*)AfxGetApp())->GetNumDevices();
	for (i = 0; i < dwNumDevices; i++)
	{
		fnPerformaxComGetProductString(i, ProductString, PERFORMAX_RETURN_SERIAL_NUMBER); 
		m_CombDeviceList.InsertString(i,(LPCTSTR)ProductString);
	}
	m_CombDeviceList.SetCurSel(0);

	m_bIsConnected = FALSE;
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPerformaxVCSampleDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPerformaxVCSampleDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPerformaxVCSampleDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CPerformaxVCSampleDlg::OnConnect() 
{
	CString str, strErr;
	int		n1, n2;
    if (fnPerformaxComSetTimeouts(10000, 10000))
	{
		n1 = m_CombDeviceList.GetCurSel();
		if (!fnPerformaxComOpen(n1, &m_hUSBDevice))
		{
			n2 = m_CombDeviceList.GetLBTextLen(n1);
			m_CombDeviceList.GetLBText(n1, str.GetBuffer(n2));
			str.ReleaseBuffer();
			strErr.Format(_T("Error opening device %s. Reset hardware and try again."), str.GetBuffer(0));
			MessageBox(strErr);
		}
		else
		{
			m_bIsConnected = TRUE;
			m_BtnDisConnect.EnableWindow(TRUE);
			m_BtnSend.EnableWindow(TRUE);
			m_BtnConnect.EnableWindow(FALSE);
			m_CombDeviceList.EnableWindow(FALSE);
		}
	}
	else
		MessageBox("Error to set timeouts. Reset hardware and try again.");  
}

void CPerformaxVCSampleDlg::OnDisconnect() 
{
	if (m_hUSBDevice != NULL)
	{
		fnPerformaxComClose(m_hUSBDevice);
		m_BtnDisConnect.EnableWindow(FALSE);
		m_BtnSend.EnableWindow(FALSE);
		m_BtnConnect.EnableWindow(TRUE);
		m_CombDeviceList.EnableWindow(TRUE);
		m_bIsConnected=FALSE;
	}
}

void CPerformaxVCSampleDlg::OnSend() 
{
	char	CmdBuffer[64], ResponseBuffer[64];
	CString	strReply;
	DWORD	i;

	UpdateData(TRUE);
	memset(CmdBuffer,0,sizeof(CmdBuffer));
	strcpy(CmdBuffer, m_strCommand);
	
	if (m_bIsConnected)
	{
		if (strlen(CmdBuffer)>0){
			if (fnPerformaxComSendRecv(m_hUSBDevice, CmdBuffer, 64, 64, ResponseBuffer))
			{
				for (i = 0; i < 64; i++)
				{
					if (ResponseBuffer[i] == 0x00) // EOT - End of Transmission
						break;
					strReply += ResponseBuffer[i];
				}
				UpdateData(TRUE);
				m_ListBoxReply.AddString(strReply);
				i = m_ListBoxReply.GetCount()-1;
				m_ListBoxReply.SetCurSel(i);
				UpdateData(FALSE);
			}
		}
		m_strCommand.Empty();
		UpdateData(FALSE);
    }
	else
		MessageBox("Not connected.");
}

void CPerformaxVCSampleDlg::OnOK() 
{
//	if (m_bIsConnected ==TRUE) {
//		MessageBox("Disconnect first before exiting!");
//	}
//	else{
		CDialog::OnOK();
//	}
}

void CPerformaxVCSampleDlg::OnChangeEditCommand() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	
}

//DEL void CPerformaxVCSampleDlg::OnButtonReset() 
//DEL {
//DEL 	int status;
//DEL 	status = fnPerformaxComUSBReset(m_hUSBDevice);
//DEL 	if (status == 1) MessageBox("USB device resetted");
//DEL }

void CPerformaxVCSampleDlg::OnButtonFlush() 
{
	int status;
	status = fnPerformaxComFlush(m_hUSBDevice);
	if (status == 1) MessageBox("USB device flushed");
	
}
