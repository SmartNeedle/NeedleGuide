Compiler Helper

1) Prepare "sa_compile_decompile_setup.txt" configuration file
   and then execute the .exe.

2) For compile operations the output will be written to "CompileOut.txt"

3) For decompile operations the output will be written to "DecompileOut.prg"

4) Explanation of configuration file: "sa_compile_decompile_setup.txt"

MOD: Arcus Model (PMX-4EX-SA, PMX-2EX-SA, etc)
OPE: COMPILE/DECOMPILE
FIL: Filename to be compiled/decompiled depending on the "OPE" parameter.
VER: Firmware version of controller

Example:
MOD:PMX-4EX-SA
OPE:COMPILE
FIL:Test.prg
VER:144